// function test(){
//     const btm = document.querySelector(".btm")
//     btm.classList.add("star")
// }
// $(document).ready(function(){
//     $(".btm").on("click", function(){
//         $(".btm").addClass("star")
//     })
// })
// function test(){
//     if(value == false){
//         value == true
//     }
// }
var name;
function getName(){
  name = prompt()
  if(!name){
    name="익명"
  }
  return name;
}
getName()