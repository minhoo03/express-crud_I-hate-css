const express = require('express')
const fs = require('fs')
const template = require('./lib/template.js')
const path = require('path');
var qs = require('querystring');
const app = express()
const port = 3000


//'/' 주소가 요청으로 날라오면 콜백 실행
//파일 목록 배열로 읽어오기 시작('./data'), 콜백
//template 변수로 만들어준 template.js 내용 끌고옴
//매개변수에 우리가 주고 싶은 내용 다 넣어서
//콜백에 돌려줌
//그럼 그 값을 템플릿.js 틀에 내용을 다 박고
//응답하다(html내용을 보내서)

// app.use('/public', express.static('public'))
app.use('/public',express.static('./public'))
app.get('/', (request, response) =>{
  fs.readdir('./data', (err, filelist) =>{
    var title = 'Welcome!'
    var description = '드롭다운과 같은 간단하지만 오래 걸리는 코드 저장소. 디자인에 시간을 쏟지 말고 더 퀄리티 높은 웹을 만드세요.'
    var list = template.list(filelist)
    var html = template.HTML(title, 
    `
    <div class="list">
    <h2>List</h2><br>
    <ul>
       ${list}
    </ul>
    </div>
    `, 
      `
      <section class="content">
      <article class="html5">
          <h2 class="content_title">${title}</h2>
          <pre>${description}</pre>
          <h2 class="content_title" style=" padding-bottom:20px; margin-top:40px; margin-bottom:40px">Example
          <pre>
          <h2 class="content_title">HTML</h2>
          <pre>
Write HTML!
          </pre>
          <h2 class="content_title">CSS</h2>
          <pre>
Write CSS!!!
          </pre>
          <h2 class="content_title">JS</h2>
          <pre>
Write JS...
          </pre>
          </pre>
          </h2>


      </article>
      `, 
      `
      <button class="btn btn-light" ><a href="/create">create</a></button>
      `)
      response.send(html)
  })
})




//get으로 요청보낸 req의 params로 응답
app.get('/page/:pageId', (request,response) =>{
  fs.readdir('./data', function(error, filelist){
    var filteredId = path.parse(request.params.pageId).base;
    fs.readFile(`data/${filteredId}`, 'utf8', function(err, data){
      data = JSON.parse(data)
      let {description, htmlcode,csscode,jscode} = data
      var title = request.params.pageId;
      // title.replace(`${title}.json`,`${title}`)
      var list = template.list(filelist);
      var html = template.HTML(title, 
        `
        <div class="list">
        <h2>List</h2><br>
        <ul>
          ${list}
        </ul>
        </div>
        `
        ,
        `
                <section class="content">
                    <article class="html5">
                        <h2 class="content_title">${title}</h2>
                        <pre>${description}</pre>
                        <h2 class="content_title">HTML</h2>
                        <pre style="max-height : 500px;">
    ${htmlcode}
                        </pre>
                        <h2 class="content_title">CSS</h2>
                        <pre style="max-height : 500px;">
    ${csscode}
                        </pre>
                        <h2 class="content_title">JS</h2>
                        <pre style="max-height : 500px;">
    ${jscode}
                        </pre>
                        
                    
                        </article>
                </section>`,
        ` <button class="btn btn-light" ><a href="/create">create</a></button>
          <button class="btn btn-light" ><a href="/update/${title}">update</a><button>
          <form style="padding:0px;" action="delete_process" method="post">
            <input type="hidden" name="id" value="${title}">
            <input  class="btn btn-light"  type="submit" value="delete">
          </form>`
      );
      console.log(`Read ${title}`)
      response.send(html);
    });
  });
})
//get 요청 들어오면 콜백함수 실행
//받은 요청과 보낼 응답 = 매개변수
//fs.readdir = 파일 목록 읽어오기(배열)
//'이 폴더의 내용 읽기', 콜백 실행(에러, 담아온 내용)
//list에 긁어온 내용 넣어줌
//html 변수에 title, list , body, control 넣어줌 <- 템플릿.js 매개변수 내용
//요청 받은 곳에 응답으로 변수 html 보내줌
//그럼 템플릿.js 매개변수에 우리가 넣어준 내용을 담고
//'/create'로 날라감
app.get('/create', (request, response) => {
  fs.readdir('./data', function(error, filelist){
    var title = 'WEB - create';
    var list = template.list(filelist);
    var html = template.HTML(title, 
      `
      <div class="list">
        <h2>List</h2><br>
        <ul>
          ${list}
        </ul>
        </div>
      `
      , `
      <form action="/create_process" method="post">
      <h2>Create</h2>
      <pre><a href="http://parkjuwan.dothome.co.kr/webapp/ltgt_conv/" target="_blank">HTML 코드 변환 사이트</a></pre>
        <p><input type="text" name="title" placeholder="title"></p>
        <p>
          <textarea name="description" class="areaWidth"  placeholder="description"></textarea>
        </p>
        <p>
          <textarea name="htmlcode" class="areaWidth"  placeholder="write html..."></textarea>
        </p>
        <p>
          <textarea name="csscode" class="areaWidth"  placeholder="write css..."></textarea>
        </p>
        <p>
          <textarea name="jscode" class="areaWidth"  placeholder="write js..."></textarea>
        </p>
        <p>
          <input class="btn btn-primary" type="submit">
        </p>
      </form>
    `, '');
    response.send(html);
  });
})
//request.on('data', function(data){} 는 요청으로 온 data을 일정 기준 조각내 받음
//body에 들어온 데이터를 계속하여 추가
//request.on('end', function(){} 은 데이터가 다 들어왔을 때 쿼리스트링 형태 바꿔줌

//7-11 AM.01:17 드디어 성공!!!
app.post('/create_process', (request, response) =>{
  var body = '';
      request.on('data', function(data){
          body = body + data;
      });
      request.on('end', function(){
          var post = qs.parse(body);
          var title = post.title;
          // let data = {description, htmlcode, csscode, jscode}

          const data = {description:post.description,
                        htmlcode:post.htmlcode,
                        csscode:post.csscode,
                        jscode:post.jscode}
            //JSON 형태로
          const jsonString = JSON.stringify(data)
          fs.writeFile(`data/${title}.json`, jsonString , 'utf8', function(err){
            console.log(`Create ${title}`)
            response.writeHead(302, {Location: `/page/${title}.json`});
            response.end();
          })
      });
})

app.get('/update/:pageId', (request, response) =>{
  fs.readdir('./data', function(error, filelist){
    var filteredId = path.parse(request.params.pageId).base;
    fs.readFile(`data/${filteredId}`, 'utf8', function(err, data){
      data = JSON.parse(data)
      let {description, htmlcode,csscode,jscode} = data
      var title = request.params.pageId;
      var list = template.list(filelist);
      var html = template.HTML(title, 
        `
        <div class="list">
        <h2>List</h2><br>
        <ul>
          ${list}
        </ul>
        </div>
        `
        ,
        `
        <form action="/update_process" method="post">
          <input type="hidden" name="id" value="${title}">
          <p><input type="text" name="title" placeholder="title" value="${title}"></p>
          <p>
            <textarea name="description" class="areaWidth" placeholder="description">${description}</textarea>
          </p>

          <p>
            <textarea name="htmlcode" class="areaWidth"  placeholder="htmlcode">${htmlcode}</textarea>
          </p>

          <p>
            <textarea name="csscode" class="areaWidth"  placeholder="csscode">${csscode}</textarea>
          </p>

          <p>
            <textarea name="jscode" class="areaWidth"  placeholder="jscode">${jscode}</textarea>
          </p>
          <p>
            <input type="submit">
          </p>
        </form>
        `,
        `<button class="btn btn-light"  ><a href="/create">create</a></button> <button class="btn btn-light" ><a  href="/update/${title}">update</a></button>`
      );
      response.send(html);
    });
  });
})

app.post('/update_process', (request,response)=>{
  var body = '';
  request.on('data', function(data){
      body = body + data;
  });
  request.on('end', function(){
      var post = qs.parse(body);
      var id = post.id;
      var title = post.title;
      const data = {description:post.description,
                    htmlcode:post.htmlcode,
                    csscode:post.csscode,
                    jscode:post.jscode}
//JSON 형태로
      const jsonString = JSON.stringify(data)
      fs.rename(`data/${id}`, `data/${title}`, function(error){
        fs.writeFile(`data/${title}`, jsonString, 'utf8', function(err){
          console.log(`Update ${title}`)
          response.writeHead(302, {Location: `/page/${title}`});
          response.end();
        })
      });
  });
})

app.post('/page/delete_process', (request, response) =>{
  var body = '';
  request.on('data', function(data){
      body = body + data;
  });
  // 받은 데이터의 쿼리 문자열을 객체로 바꿈
  request.on('end', function(){
          var post = qs.parse(body);
          var id = post.id
          //받은 데이터 변수에 담기
          // input의 받아온 id 가져옴(여기 value가 ${title})
          // 그 id(value)로 파싱함(파일명 추출)
          // filterdId를 사용하는 이유 : 사용자가 요청한 정보들 중 순수하게 파일명만 추출
          var filteredId = path.parse(id).base;
          var data = `data/${filteredId}`
          fs.unlink(data, function(error){
            console.log(`Delete ${filteredId}`)
            response.writeHead(302, {Location: `/`});
            response.end();

          })
      });
})

app.listen(port, () => console.log(`Open Server! -> http://localhost:${port}`))

