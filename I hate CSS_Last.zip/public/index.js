// function test(){
//     const btm = document.querySelector(".btm")
//     btm.classList.add("star")
// }
// $(document).ready(function(){
//     $(".btm").on("click", function(){
//         $(".btm").addClass("star")
//     })
// })
// function test(){
//     if(value == false){
//         value == true
//     }
// }




// var name;
// function getName(){
//   name = prompt()
//   if(!name){
//     name="익명"
//   }
//   return name;
// }
// getName()

// function getName(){
//   prompt('asd');
// }
// getName();

// console.log('asdljfalksdf');
// alert()
// const btm = document.querySelector(".btm")
// function test(){
//     btm.classList.add("star")
// }
// function test(){
//     $(this).addClass('active').siblings().removeClass('active')
//     console.log('asd')
// }


const innerNameText = document.querySelector(".nameText")

function setName(){
    const name = prompt('이름?')
    localStorage.setItem("username",name)
    location.reload()
}

function innerName(username){
    innerNameText.innerText = username +"님 반갑습니다."
}




function getName(){
    const username = localStorage.getItem("username")
    return username;
}

function init(){
    const username = getName()

    if(username == null){
        setName()
    }else{
        innerName(username)
    }
}
init()



function uploadImgPreview() {

    let fileInfo = document.getElementById("upImgFile").files[0];

    let reader = new FileReader();

    reader.onload = function() {

        document.getElementById("thumbnailImg").src = reader.result;


    };		

    if( fileInfo ) {

        reader.readAsDataURL( fileInfo );

    }

}
